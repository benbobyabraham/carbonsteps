import 'package:flutter/material.dart';
import 'package:nttgreen/screens/analytics/dashboardpage.dart';
import 'package:nttgreen/screens/analytics/dashboardpage2.dart';
import 'package:nttgreen/screens/analytics/dashboardpage3.dart';

class ToggleButton1 extends StatefulWidget {
  const ToggleButton1({super.key});

  @override
  State<ToggleButton1> createState() => _ToggleButton1State();
}

class _ToggleButton1State extends State<ToggleButton1> {
  List<bool> isSelected = [false, false];
  void _navigate1() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => DashboardPage3()));
  }

  void _navigate2() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => DashboardPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ToggleButtons(
        children: const [Text('Your Carbon Score'), Text('Compare Score')],
        constraints: const BoxConstraints(minWidth: 183, minHeight: 36),
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(12.0),
            bottomLeft: Radius.circular(12.0),
            bottomRight: Radius.circular(12.0),
            topRight: Radius.circular(12.0)),
        onPressed: (int index) {
          setState(() {
            isSelected[index] = !isSelected[index];
            if (index == 0) {
              _navigate2();
            } else {
              _navigate1();
            }
          });
        },
        isSelected: isSelected,
      ),
    );
  }
}
