import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class DoughnutChart2 extends StatefulWidget {
  const DoughnutChart2({super.key});

  @override
  State<DoughnutChart2> createState() => _DoughnutChart2State();
}

class _DoughnutChart2State extends State<DoughnutChart2> {
  Color green1 = Color(0xFF05AC72);
  Color green2 = Color(0xFF0AD48B);
  Color green3 = Color(0xFF056644);

  final List<Data> chartData = [
    Data('CarbonFootprint', 85, Color.fromARGB(255, 5, 102, 68)),
    Data('Average', 80, Color.fromRGBO(10, 212, 139, 1)),
    Data('WorldAverage', 70, Color.fromRGBO(5, 172, 114, 1)),
  ];
  Color CustomWhite = Color(0xFFFFFFFF);
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Column(
        children: [
          SizedBox(height: 16),

          Center(
            child: SfCircularChart(
                backgroundColor: CustomWhite,
                //image setting in chart
                annotations: <CircularChartAnnotation>[
                  CircularChartAnnotation(
                      widget: Container(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '214',
                            style: TextStyle(
                              fontSize: 55,
                              color: green1,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Your Carbon',
                            style: GoogleFonts.poppins(
                                fontSize: 12.6,
                                // color: Colors.green,
                                fontWeight: FontWeight.w500),
                          ),
                          Text(
                            'footprint score',
                            style: GoogleFonts.poppins(
                                fontSize: 12.6,
                                //color: Colors.green,
                                fontWeight: FontWeight.w500),
                          )
                        ],
                      ),
                    ),
                  ))
                ],
                legend: const Legend(
                    isVisible: false,

                    // offset: Offset(-70, 0),
                    position: LegendPosition.bottom,
                    orientation: LegendItemOrientation.vertical,
                    textStyle: TextStyle(fontSize: 14)),
                series: <CircularSeries>[
                  DoughnutSeries<Data, String>(
                    dataSource: chartData,
                    xValueMapper: (Data data, _) => data.Category,
                    yValueMapper: (Data data, _) => data.value,
                    pointColorMapper: (Data data, _) => data.color,
                    innerRadius: '60%',

                    // cornerStyle: CornerStyle.bothCurve
                  ),
                ]),
          ),
          //SizedBox(height: 20),
          CustomLegends(data: chartData),
          SizedBox(height: 20),
          //  KnowMoreButton(),
        ],
      ),
    ));
  }

  // List<Data> getChartData() {
  //   final List<Data> chartData = [
  //     Data('CarbonFootprint', 85, Color.fromARGB(255, 4, 168, 9)),
  //     Data('Average', 80, Color.fromARGB(236, 7, 204, 14)),
  //     Data('WorldAverage', 70, Color.fromARGB(255, 6, 235, 14)),
  //   ];
  //   return chartData;
  // }
}

class Data {
  Data(this.Category, this.value, this.color);
  final String Category;
  final int value;
  final Color color;
}

class CustomLegends extends StatelessWidget {
  final List<Data> data;
  CustomLegends({required this.data});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: data.map((chartdata) {
        return Column(
          children: [_buildLegendItems(chartdata), SizedBox(height: 8)],
        );
      }).toList(),
    );
  }

  Widget _buildLegendItems(Data chartData) {
    String value = chartData.value.toString();

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              width: 15,
              height: 15,
              color: chartData.color,
            ),
            SizedBox(
              width: 15,
            ),
            Text(chartData.Category),
          ],
        ),
        Text(value + " kg"),
      ],
    );
  }
}

// class KnowMoreButton extends StatelessWidget {
//   const KnowMoreButton({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       width: 317,
//       height: 39,
//       child: TextButton(
//         onPressed: () {
//           Navigator.push(context,
//               MaterialPageRoute(builder: (context) => DashboardPage2()));
//         },
//         style: ButtonStyle(
//             backgroundColor: MaterialStateProperty.all<Color>(
//                 Color.fromARGB(255, 5, 102, 68))),
//         child: Text(
//           'know More',
//           style: TextStyle(color: Colors.white),
//         ),
//       ),
//     );
//   }
// }
