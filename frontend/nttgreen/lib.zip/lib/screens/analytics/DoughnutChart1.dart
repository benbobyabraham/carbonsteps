import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:nttgreen/screens/analytics/RadialBarChart1.dart';
import 'package:nttgreen/screens/analytics/RadialBarChart1.dart';
import 'package:nttgreen/screens/analytics/dashboardpage2.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class DoughnutChart extends StatefulWidget {
  const DoughnutChart({super.key});

  @override
  State<DoughnutChart> createState() => _DoughnutChartState();
}

class _DoughnutChartState extends State<DoughnutChart> {
  Color green1 = Color(0xFF05AC72);
  Color green2 = Color(0xFF0AD48B);
  Color green3 = Color(0xFF056644);

  final List<Data> chartData = [
    Data('Transportation', 40, Color.fromARGB(255, 5, 102, 68)),
    Data('Accomodation', 28, Color.fromRGBO(5, 172, 114, 1)),
    Data('Fooding', 32, Color.fromRGBO(10, 212, 139, 1)),
  ];
  Color CustomWhite = Color(0xFFFFFFFF);
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Column(
        children: [
          SizedBox(height: 16),
          RichText(
            text:
                TextSpan(style: DefaultTextStyle.of(context).style, children: [
              TextSpan(
                text: "Your Carbon footprint score is ",
                style: GoogleFonts.poppins(
                    fontSize: 16.5, fontWeight: FontWeight.w500),
              ),
              TextSpan(
                  text: "214",
                  style: GoogleFonts.poppins(
                      fontSize: 23,
                      fontWeight: FontWeight.bold,
                      color: Colors.green))
            ]),
          ),
          SfCircularChart(
              backgroundColor: CustomWhite,
              //image setting in chart
              annotations: <CircularChartAnnotation>[
                CircularChartAnnotation(
                    widget: Container(
                  width: 50,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      image: AssetImage('assets/images/tree.png'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ))
              ],
              legend: const Legend(
                  isVisible: false,

                  // offset: Offset(-70, 0),
                  position: LegendPosition.bottom,
                  orientation: LegendItemOrientation.vertical,
                  textStyle: TextStyle(fontSize: 14)),
              series: <CircularSeries>[
                DoughnutSeries<Data, String>(
                  dataSource: chartData,
                  xValueMapper: (Data data, _) => data.Category,
                  yValueMapper: (Data data, _) => data.value,
                  pointColorMapper: (Data data, _) => data.color,
                  innerRadius: '60%',

                  // cornerStyle: CornerStyle.bothCurve
                ),
              ]),
          //SizedBox(height: 20),
          CustomLegends(data: chartData),
          SizedBox(height: 20),
          KnowMoreButton(),
        ],
      ),
    ));
  }

  // List<Data> getChartData() {
  //   final List<Data> chartData = [
  //     Data('CarbonFootprint', 85, Color.fromARGB(255, 4, 168, 9)),
  //     Data('Average', 80, Color.fromARGB(236, 7, 204, 14)),
  //     Data('WorldAverage', 70, Color.fromARGB(255, 6, 235, 14)),
  //   ];
  //   return chartData;
  // }
}

class Data {
  Data(this.Category, this.value, this.color);
  final String Category;
  final int value;
  final Color color;
}

class CustomLegends extends StatelessWidget {
  final List<Data> data;
  CustomLegends({required this.data});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: data.map((chartdata) {
        return Column(
          children: [_buildLegendItems(chartdata), SizedBox(height: 8)],
        );
      }).toList(),
    );
  }

  Widget _buildLegendItems(Data chartData) {
    String value = chartData.value.toString();

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              width: 15,
              height: 15,
              color: chartData.color,
            ),
            SizedBox(
              width: 15,
            ),
            Text(chartData.Category),
          ],
        ),
        Text(value + " %"),
      ],
    );
  }
}

class KnowMoreButton extends StatelessWidget {
  const KnowMoreButton({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 317,
      height: 39,
      child: TextButton(
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => DashboardPage2()));
        },
        style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(
                Color.fromARGB(255, 5, 102, 68))),
        child: Text(
          'know More',
          style: GoogleFonts.poppins(color: Colors.white),
        ),
      ),
    );
  }
}
