import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class Chart extends StatefulWidget {
  const Chart({super.key});

  @override
  State<Chart> createState() => _ChartState();
}

class _ChartState extends State<Chart> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 25.0),
      child: SfCartesianChart(
          // borderColor: Colors.black87,
          // plotAreaBorderColor: Colors.transparent,
          title: ChartTitle(
              text: '        World Carbon Emission',
              alignment: ChartAlignment.near,
              textStyle: GoogleFonts.poppins(
                  color: Color.fromARGB(255, 5, 102, 68),
                  fontSize: 14,
                  fontWeight: FontWeight.w500)),
          primaryXAxis: CategoryAxis(
            // title: AxisTitle(text: 'year'),
            majorGridLines: MajorGridLines(width: 0),
            axisLine: AxisLine(width: 0),
          ),
          primaryYAxis: NumericAxis(
            majorGridLines: MajorGridLines(
              width: 1,
              color: Colors.green,
            ),
            axisLine: AxisLine(width: 0),
            labelStyle: GoogleFonts.poppins(color: Colors.transparent),
            //  majorTickLines: MajorTickLines(color: Colors.red)
          ),
          series: <SplineSeries<GraphData, int>>[
            SplineSeries<GraphData, int>(
                color: Color.fromARGB(255, 5, 102, 68),
                dataSource: <GraphData>[
                  GraphData(30, 2017),
                  GraphData(50, 2018),
                  GraphData(70, 2019),
                  GraphData(55, 2020),
                  GraphData(79, 2022),
                ],
                xValueMapper: (GraphData sales, _) => sales.year,
                yValueMapper: (GraphData sales, _) => sales.num,
                markerSettings: MarkerSettings(
                  isVisible: true,
                  color: Color.fromARGB(255, 5, 102, 68),
                ))
          ]),
    );
  }
}

class GraphData {
  GraphData(this.num, this.year);
  final int year;
  final int num;
}
