class Constants {
  static String authToken = '';
  static String userName = '';
  static String email = '';
}

const baseURL = "http://10.138.50.145:8000";
final String token = Constants.authToken;
final String username = Constants.userName;
final String email = Constants.email;
